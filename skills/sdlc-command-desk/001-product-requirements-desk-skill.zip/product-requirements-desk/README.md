# Product Requirements Desk

`product-requirements-desk` creates connector-grounded PRDs and requirements artifacts for the first major requirements stage of the SDLC suite.

## Expected inputs

- Raw product idea or feature brief
- GitHub issues, labels, milestones, and discussions
- Customer notes, support themes, roadmap context, and stakeholder decisions
- Existing PRDs, specs, discovery docs, or uploaded documents
- Repo context when the requirement depends on existing product or technical behavior

## Expected outputs

- Product Requirements Document
- Requirement inventory with stable IDs
- Acceptance criteria
- Non-goals and scope boundaries
- Risks, mitigations, and open questions
- Source-fact evidence and unverified assumptions
- Downstream handoff notes for SRS, architecture, issue planning, verification, and PR prompts

## Required connectors

Use GitHub when requirements depend on issues, repo context, milestones, PRs, labels, or implementation history. Use durable document sources such as uploaded docs, Drive, Notion, or SharePoint when requirements depend on strategy, roadmap, research, or existing specs. Use communication sources only for recent decisions not captured in durable docs.

## Composition with PR Command Desk

This skill does not produce implementation PR prompts directly unless requirements are already bounded and accepted. It prepares the requirement and acceptance-criteria evidence that `pr-command-desk` later uses to create grounded implementation handoff prompts.
