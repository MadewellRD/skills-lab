# Halt Conditions

Halt or produce `product-discovery-diagnostic.md` instead of a confident PRD when any condition below applies.

## Required halt conditions

- The target users or stakeholders are unknown and cannot be inferred from supplied context.
- The problem statement is unclear or conflicts across sources.
- The requested PRD depends on GitHub issues, roadmap docs, or stakeholder decisions that are unavailable.
- Source facts conflict on priority, scope, release target, or user segment.
- Acceptance criteria would require inventing behavior or metrics.
- The user asks for implementation-ready requirements but technical feasibility is unknown.
- The request depends on current repo behavior and GitHub/repo context is unavailable.
- The user asks to remove or hide uncertainty rather than preserve open questions.

## Diagnostic structure

Use this structure when halted:

```markdown
# Product Discovery Diagnostic

## How to use this file

Resolve the missing or conflicting inputs below before treating the product requirements as ready for downstream SDLC work.

## Blocking gaps

- gap and why it blocks requirement drafting

## Conflicting source facts

- conflict and sources

## Questions for resolution

- question, suggested owner, and downstream impact

## Safe partial output

- requirements or assumptions that can be drafted safely
```
