# PRD Template and Requirement Inventory

Use this reference when creating a full Product Requirements Document or a requirements-only artifact.

## Full PRD structure

```markdown
# Product Requirements Document: Title

Status: Draft | Review | Approved
Owner: Name or unassigned
Last updated: Date if known

## How to use this file

Use this PRD as the source artifact for SRS, architecture, issue planning, verification, and implementation handoff work. Treat source facts as verified context and assumptions as items requiring confirmation.

## Executive summary

One concise paragraph describing the product change, target users, and expected outcome.

## Source facts

- Fact: concise verified statement. Source: connector, document, issue, or user-provided context.
- Assumption: concise unverified statement requiring confirmation.
- Conflict: conflicting statements and recommended resolution path.

## Problem statement

Describe the user or business problem. Do not start with the solution unless the user explicitly provided an implementation constraint.

## Users and stakeholders

- Primary users
- Secondary users
- Internal stakeholders
- Decision owners if known

## Goals

- Goal statements tied to measurable outcomes when possible.

## Non-goals

- Explicit exclusions and deferred work.

## Requirements

### Functional requirements

| ID | Requirement | Priority | Source | Acceptance criteria |
|---|---|---|---|---|
| PRD-FR-001 | User-facing behavior or capability | must | source fact | measurable criteria |

### Non-functional requirements

| ID | Requirement | Priority | Source | Verification |
|---|---|---|---|---|
| PRD-NFR-001 | Performance, reliability, security, accessibility, data, or compliance requirement | should | source fact | verification method |

## Acceptance criteria

- PRD-AC-001: measurable condition of satisfaction.

## Analytics and success metrics

- Metric name
- Baseline if known
- Target if known
- Measurement source

## Dependencies and constraints

- Product, technical, operational, legal, compliance, support, or design constraints.

## Risks and mitigations

| ID | Risk | Impact | Likelihood | Mitigation |
|---|---|---|---|---|
| PRD-RISK-001 | concise risk | low/medium/high | low/medium/high | mitigation |

## Open questions

| ID | Question | Owner | Blocking? | Resolution needed by |
|---|---|---|---|---|
| PRD-OQ-001 | question | owner or unassigned | yes/no | milestone/date if known |

## Downstream handoff notes

- For SRS: requirement groups requiring formal system requirements.
- For architecture: components, integrations, or constraints likely to affect design.
- For issue planning: likely epics, slices, labels, and dependencies.
- For verification: acceptance criteria and evidence needed.
- For PR Command Desk: implementation-ready scope only after unresolved blockers are cleared.

## Evidence block

- Sources used
- Sources unavailable
- Unverified assumptions
- Conflicts preserved
```

## Requirement writing rules

- Write requirements as observable product behavior or constraints.
- Avoid vague verbs such as improve, enhance, support, or handle unless followed by a measurable condition.
- Use one requirement per row.
- Separate product outcome from implementation detail unless the implementation is a hard constraint.
- Preserve uncertainty in open questions rather than burying it in requirements.
- Use priority terms consistently: `must`, `should`, `could`, `deferred`.

## PRD review checklist

A PRD is ready for downstream work only when it has:

- clear problem statement
- named users or user classes
- goals and non-goals
- stable requirement IDs
- acceptance criteria for must-have requirements
- source facts and assumptions separated
- open questions marked blocking or non-blocking
- downstream handoff notes
