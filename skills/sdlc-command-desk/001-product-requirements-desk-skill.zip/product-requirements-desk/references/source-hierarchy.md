# Source Hierarchy

Use this truth order when sources conflict:

1. explicit instruction from the current user message
2. current durable product documents, roadmap docs, and accepted specs
3. GitHub issues, labels, milestones, PRs, and repo docs
4. recent stakeholder decisions from communication connectors
5. uploaded notes or pasted context
6. public web facts for external products, APIs, or market context
7. model inference, only when labeled as assumption

## Conflict handling

Do not merge conflicting claims into a false compromise. Preserve the conflict in the PRD source facts and either:

- ask the user to resolve it when it changes requirements materially
- mark the affected requirement as blocked
- produce a diagnostic artifact instead of a PRD when the conflict prevents safe drafting

## Source-fact format

Use compact source facts:

```markdown
- Fact: user admins need bulk invitation controls. Source: GitHub issue #42 and roadmap note.
- Assumption: enterprise plans require audit logging. Source: inferred from user-provided goal; unverified.
- Conflict: roadmap says mobile first, issue labels say web first. Resolution needed before implementation planning.
```
