# Connector Routing

Use this routing table before drafting requirements.

## New product idea from chat only

Required sources:

- current user message
- uploaded documents if provided

Optional sources:

- roadmap docs
- GitHub issues
- related repo docs

Behavior:

- Produce a clearly labeled draft.
- Mark assumptions explicitly.
- Do not claim stakeholder agreement or technical feasibility without source evidence.

## Issue-derived PRD

Required sources:

- GitHub Issues or equivalent ticket source
- issue comments when decision history matters
- labels, milestone, priority, and linked PRs when available

Optional sources:

- repo README and product docs
- roadmap docs
- support/customer notes

Behavior:

- Preserve issue IDs in source facts.
- Group duplicate or related issues into requirement themes.
- Halt if the requested PRD depends on unavailable issues or private context.

## Roadmap or strategy-derived PRD

Required sources:

- roadmap, strategy, planning, or initiative docs
- current user instruction

Optional sources:

- stakeholder decision messages
- GitHub milestones
- existing PRDs or specs

Behavior:

- Keep strategic claims tied to source facts.
- Halt if roadmap priority or target audience conflicts across sources.

## Existing product or repo behavior PRD

Required sources:

- GitHub repo context when behavior depends on current implementation
- docs or README describing current behavior

Optional sources:

- prior PRs or issues
- test names and code paths

Behavior:

- Separate current behavior from desired behavior.
- Do not invent code paths, test names, or implementation feasibility.

## Decision-history PRD

Required sources:

- durable docs for final decisions
- Slack, Teams, email, or pasted halt reports only when durable docs are missing

Behavior:

- Treat communications as decision context, not repo truth.
- Preserve date, speaker, and decision summary when available.
- Halt if communications conflict with durable docs and the user has not resolved the conflict.
