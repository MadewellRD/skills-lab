# Downstream Handoff

Use this reference to prepare output for later SDLC skills.

## To software-requirements-desk

Provide:

- PRD title and status
- functional and non-functional requirement IDs
- acceptance criteria
- constraints
- unresolved open questions

Do not pass assumptions as requirements.

## To technical-discovery-desk

Provide:

- technical unknowns
- integration questions
- feasibility risks
- dependencies and constraints
- repo or API areas likely affected

## To architecture-design-desk

Provide:

- product goals and non-goals
- NFRs affecting architecture
- data, API, workflow, and security constraints
- migration or compatibility requirements

## To issue-planning-desk

Provide:

- requirement groups
- candidate epics
- acceptance criteria
- dependencies
- priority and sequencing notes

## To verification-desk

Provide:

- requirement IDs
- acceptance criteria
- measurable outcomes
- testability notes
- evidence required for acceptance

## To pr-command-desk

Provide only implementation-ready scope:

- bounded requirement IDs
- explicit non-goals
- accepted constraints
- source facts
- validation gates
- unresolved questions that should become halt conditions
