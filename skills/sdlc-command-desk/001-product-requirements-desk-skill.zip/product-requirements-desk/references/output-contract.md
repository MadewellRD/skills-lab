# Output Contract

Default to downloadable Markdown artifacts for PRDs, requirement inventories, reviews, and diagnostics.

## Artifact filenames

- Full PRD: `product-requirements-document.md`
- Requirements-only extraction: `requirements-inventory.md`
- PRD critique: `prd-review-report.md`
- Missing-context report: `product-discovery-diagnostic.md`
- Downstream handoff notes: `requirements-handoff-notes.md`

## Wrapper rule

Every artifact must start with a title and a short usage section:

```markdown
# Artifact Title

## How to use this file

Use this artifact as the product source for downstream SDLC work. Preserve requirement IDs, source facts, assumptions, and open questions when handing work to another skill or implementation agent.
```

## Evidence block

Include an evidence block at the end of every artifact unless the user asks for a brief inline answer:

```markdown
## Evidence block

### Sources used
- source and relevant fact

### Sources unavailable
- source needed but unavailable

### Unverified assumptions
- assumption and why it matters

### Preserved conflicts
- conflict and required resolution
```

## Chat response

When a file is produced, respond with:

- a link to the file
- one sentence explaining the recommended downstream use

Do not paste the whole artifact in chat unless the user asks for inline text.
