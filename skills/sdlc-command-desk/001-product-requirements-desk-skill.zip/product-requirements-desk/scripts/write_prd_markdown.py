#!/usr/bin/env python3
"""Wrap a generated PRD body in a stable Markdown artifact structure."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable


def bullet_list(title: str, values: Iterable[str]) -> str:
    items = [value.strip() for value in values if value.strip()]
    if not items:
        return f"### {title}\n- none recorded\n"
    return f"### {title}\n" + "\n".join(f"- {item}" for item in items) + "\n"


def build_document(
    title: str,
    body: str,
    sources: list[str],
    unavailable: list[str],
    assumptions: list[str],
    conflicts: list[str],
) -> str:
    clean_title = title.strip() or "Product Requirements Document"
    clean_body = body.strip()
    sections = [
        f"# {clean_title}",
        "## How to use this file",
        "Use this artifact as the product source for downstream SDLC work. Preserve requirement IDs, source facts, assumptions, and open questions when handing work to another skill or implementation agent.",
        clean_body,
        "## Evidence block",
        bullet_list("Sources used", sources),
        bullet_list("Sources unavailable", unavailable),
        bullet_list("Unverified assumptions", assumptions),
        bullet_list("Preserved conflicts", conflicts),
    ]
    return "\n\n".join(section for section in sections if section).rstrip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a PRD Markdown artifact with evidence sections.")
    parser.add_argument("--title", default="Product Requirements Document")
    parser.add_argument("--body-file", required=True, help="Path to a Markdown file containing the PRD body.")
    parser.add_argument("--output", required=True, help="Path to write the wrapped artifact.")
    parser.add_argument("--source", action="append", default=[], help="Verified source fact. Repeatable.")
    parser.add_argument("--unavailable", action="append", default=[], help="Unavailable source needed for stronger grounding. Repeatable.")
    parser.add_argument("--assumption", action="append", default=[], help="Unverified assumption. Repeatable.")
    parser.add_argument("--conflict", action="append", default=[], help="Preserved source conflict. Repeatable.")
    args = parser.parse_args()

    body_path = Path(args.body_file)
    if not body_path.exists():
        raise SystemExit(f"body file not found: {body_path}")
    body = body_path.read_text(encoding="utf-8")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        build_document(args.title, body, args.source, args.unavailable, args.assumption, args.conflict),
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
