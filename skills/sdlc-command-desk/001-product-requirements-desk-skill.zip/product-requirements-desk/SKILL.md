---
name: product-requirements-desk
description: create connector-grounded product requirements documents and downstream requirement artifacts from ideas, customer notes, issues, roadmap docs, discovery material, and stakeholder decisions. use when chatgpt needs to turn product intent into a prd, requirement ids, acceptance criteria, non-goals, open questions, risks, source-facts evidence, or handoff notes for srs, architecture, issue planning, verification, or pr-command-desk workflows.
---

# Product Requirements Desk

## Purpose

Use this skill to turn early product intent into a grounded product requirements artifact. The skill produces PRDs, requirement inventories, acceptance criteria, non-goals, open questions, source-fact evidence, and downstream handoff notes for later SDLC skills.

The skill does not invent product truth. It separates verified facts from assumptions and uses connector diagnostics when required evidence is missing.

## Operating workflow

1. Classify the request.
   - New product idea or brief: create a PRD from provided and connector-grounded context.
   - Existing issue or request cluster: synthesize a PRD from issues, comments, labels, and related docs.
   - PRD review: critique an existing PRD against the quality checklist in `references/prd-template.md`.
   - Requirement extraction: produce requirement IDs, acceptance criteria, non-goals, risks, and open questions without a full PRD when requested.
   - Downstream handoff: produce SRS, architecture, issue-planning, verification, or `pr-command-desk` handoff notes.

2. Run connector preflight.
   Use `references/connector-routing.md` to decide which sources are required. Use GitHub for issues, repo context, labels, milestones, and existing product-facing bugs. Use docs connectors or uploaded docs for roadmap, strategy, specs, research, and decision records. Use communication connectors only for recent decisions or stakeholder context not captured in durable docs.

3. Build a source-fact inventory.
   Before drafting requirements, record product facts, user evidence, constraints, conflicts, assumptions, and missing inputs. Apply the truth order in `references/source-hierarchy.md`.

4. Produce the artifact.
   Use `references/prd-template.md` for full PRDs and `references/output-contract.md` for artifact naming, evidence blocks, and downstream handoff sections.

5. Halt or diagnose when evidence is insufficient.
   Use `references/halt-conditions.md` when the request depends on unavailable connectors, conflicting source facts, missing acceptance criteria, unclear users, unclear problem statement, or unresolved priority conflicts.

## Default output behavior

When asked to create or update a PRD or requirements artifact, produce a downloadable Markdown file by default. Use one of these filenames unless the user specifies another name:

- `product-requirements-document.md`
- `requirements-inventory.md`
- `prd-review-report.md`
- `product-discovery-diagnostic.md`

Every full PRD must include:

- title and status
- source-facts summary
- problem statement
- users and stakeholders
- goals and non-goals
- functional requirements with stable IDs
- non-functional requirements with stable IDs when relevant
- acceptance criteria
- risks and mitigations
- open questions
- downstream handoff notes
- evidence block or companion source-notes section

If file writing is unavailable, output the complete Markdown artifact in a fenced block and tell the user what filename to save it as.

## Requirement ID rules

Use stable requirement IDs that downstream skills can cite:

- `PRD-FR-001` for functional requirements
- `PRD-NFR-001` for non-functional requirements
- `PRD-AC-001` for acceptance criteria when separate IDs are useful
- `PRD-RISK-001` for product or delivery risks
- `PRD-OQ-001` for open questions

Do not renumber existing IDs during updates unless the user explicitly requests a clean rewrite. Mark removed requirements as superseded or removed in change notes instead of silently deleting traceability.

## Composition with other SDLC skills

- Hand off product requirements to `software-requirements-desk` or later SRS creation.
- Hand off technical unknowns to `technical-discovery-desk`.
- Hand off design implications to `architecture-design-desk`.
- Hand off issue-ready slices to `issue-planning-desk`.
- Hand off implementation-ready work to `pr-command-desk` only after requirements, acceptance criteria, and source facts are concrete enough for a bounded implementation prompt.

## Resources

- `references/prd-template.md`: canonical PRD and requirement inventory structure.
- `references/connector-routing.md`: connector requirements by product-requirements task shape.
- `references/source-hierarchy.md`: source precedence and conflict handling.
- `references/output-contract.md`: artifact naming, evidence block, and downloadable Markdown rules.
- `references/halt-conditions.md`: stop conditions and diagnostic artifact requirements.
- `references/downstream-handoff.md`: how to hand product requirements to later SDLC skills.
- `scripts/write_prd_markdown.py`: optional helper for wrapping generated Markdown with metadata and source facts.
