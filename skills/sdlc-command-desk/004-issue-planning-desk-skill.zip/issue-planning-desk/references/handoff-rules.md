# Handoff Rules

Use `issue-planning-desk` to prepare work. Use `pr-command-desk` to create implementation-agent prompts.

A handoff to `pr-command-desk` should include:

- issue title and body
- source requirement IDs
- target repo and branch assumptions
- likely files or modules
- dependencies and blockers
- acceptance criteria
- validation commands
- out-of-scope boundaries
- halt conditions

Do not ask an implementation agent to infer missing requirements from an issue title alone.
