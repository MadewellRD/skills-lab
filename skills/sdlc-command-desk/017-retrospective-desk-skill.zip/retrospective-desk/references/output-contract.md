# Output Contract

Default artifact names:

- `retrospective-report.md`
- `lessons-learned.md`
- `cycle-metrics-summary.md`
- `process-improvement-plan.md`
- `action-item-tracker.md`
- `retrospective-source-notes.md`

For downloadable Markdown artifacts, use:

```markdown
# <artifact title>

## How to use this file

Use this retrospective to review delivery outcomes, assign improvement actions, and route follow-up work to the appropriate SDLC desk.

## Report

<content>
```

Every artifact must include source facts or a source-notes companion when connector evidence is used.
